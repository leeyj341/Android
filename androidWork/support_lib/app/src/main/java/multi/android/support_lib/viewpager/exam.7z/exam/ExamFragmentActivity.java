package multi.android.support_lib.viewpager.exam;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentPagerAdapter;
import androidx.fragment.app.FragmentTransaction;
import androidx.lifecycle.Lifecycle;
import androidx.viewpager.widget.ViewPager;

import java.util.ArrayList;

import multi.android.support_lib.R;

public class ExamFragmentActivity extends AppCompatActivity {
    ViewFragment1 viewFragment1 = new ViewFragment1();
    ViewFragment2 viewFragment2 = new ViewFragment2();
    ViewFragment3 viewFragment3 = new ViewFragment3();
    ViewFragment4 viewFragment4 = new ViewFragment4();

    ArrayList<Fragment> fragmentlist = new ArrayList<Fragment>();
    ViewPager mainPager;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_pager_exam);
        mainPager = findViewById(R.id.examMainPager);

        Button btn1 = findViewById(R.id.button);
        Button btn2 = findViewById(R.id.button2);
        Button btn3 = findViewById(R.id.button3);

        btn1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeFragment("first");
            }
        });
        btn2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeFragment("second");
            }
        });
        btn3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                changeFragment("third");
            }
        });

        fragmentlist.add(viewFragment1);
        fragmentlist.add(viewFragment2);
        fragmentlist.add(viewFragment3);
        fragmentlist.add(viewFragment4);

        MainFragmentPagerAdapter adapter = new MainFragmentPagerAdapter(getSupportFragmentManager(),
                FragmentPagerAdapter.BEHAVIOR_RESUME_ONLY_CURRENT_FRAGMENT);
        mainPager.setAdapter(adapter);
    }

    public void changeFragment(String name) {
        FragmentManager manager = getSupportFragmentManager();
        //프래그먼트의 변화를 관리하는 객체
        FragmentTransaction transaction = manager.beginTransaction();

        switch (name) {
            case "first":
                transaction.replace(R.id.container, viewFragment1);
                break;
            case "second":
                transaction.replace(R.id.container, viewFragment2);
                break;
            case "third":
                transaction.replace(R.id.container, viewFragment3);
                break;
        }

        transaction.commit();
    }

    class MainFragmentPagerAdapter extends FragmentPagerAdapter {
        public MainFragmentPagerAdapter(@NonNull FragmentManager fm, int behavior) {
            super(fm, behavior);
        }

        @NonNull
        @Override
        public Object instantiateItem(@NonNull ViewGroup container, int position) {
            return super.instantiateItem(container, position);
        }

        @NonNull
        @Override
        public Fragment getItem(int position) {
            return fragmentlist.get(position);
        }

        @Override
        public int getCount() {
            return fragmentlist.size();
        }
    }
}
